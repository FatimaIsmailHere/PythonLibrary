from .calculator import multiply, divide, power, percentage, average
from .formatter import make_bold, greet_user, reverse_text, word_count, capitalize_all