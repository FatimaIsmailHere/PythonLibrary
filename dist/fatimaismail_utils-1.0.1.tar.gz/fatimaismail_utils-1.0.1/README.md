# Fatima Utils

A versatile Python library for common mathematical calculations and string formatting.

## Installation
```bash
pip install fatima_utils